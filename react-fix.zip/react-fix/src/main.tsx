import './react-global'   // EN ÜSTTE — global React güvenlik ağı, diğer importlardan önce
import * as React from 'react'
import ReactDOM from 'react-dom/client'
import App from './app/App.tsx'
import './styles/index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><App /></React.StrictMode>,
)
