// Güvenlik ağı: React'i global kapsama koyar.
// Canlı repoda herhangi bir dosya React'i import etmeden React.useState / React.memo
// / React.createElement vb. kullansa bile, bare `React` referansı runtime'da buraya
// düşer ve "ReferenceError: React is not defined" hatası oluşmaz.
// Bu dosya main.tsx içinde EN ÜSTTE, diğer tüm importlardan ÖNCE import edilmelidir,
// çünkü ES modül importları sırayla çalışır ve üst seviye React.createContext() gibi
// çağrılar uygulama ağacı yüklenmeden önce çözülmüş olmalıdır.
import * as React from 'react';

(globalThis as unknown as { React: typeof React }).React = React;

export {};
